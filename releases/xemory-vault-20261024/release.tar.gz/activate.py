#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,urllib.request,urllib.error

RELEASE=Path('/var/www/xemory-vault-20261024')
CONFIG=Path('/etc/nginx/sites-available/xemorysystems')
OLD='/var/www/xemory-woodcarving-20261022/homepage'
DOMAIN='https://www.xemorysystems.com'
ROUTES=['/lab','/creative-request','/about','/contact','/terms','/privacy','/woodcarving/','/site-analytics/','/creative-admin','/robots.txt','/sitemap.xml','/icon.svg']
def digest(data):return hashlib.sha256(data).hexdigest()
def route(path):
    request=urllib.request.Request(DOMAIN+path,headers={'Cache-Control':'no-cache','User-Agent':'XemoryReleaseVerification/1.0'})
    try: response=urllib.request.urlopen(request,timeout=30)
    except urllib.error.HTTPError as e:response=e
    return {'status':response.status,'sha256':digest(response.read())}
def patch(original):
    if original.count(OLD)!=2 or '# End Xemory kinetic homepage' not in original:
        raise RuntimeError('Homepage routing changed; inspect before activation')
    return original.replace(OLD,str(RELEASE/'site'))
def main():
    if os.geteuid()!=0:raise RuntimeError('Root hosting console required')
    manifest=json.loads((RELEASE/'manifest.json').read_text())
    for name,sha in manifest.items():
        file=(RELEASE/name).resolve()
        if not file.is_relative_to(RELEASE) or digest(file.read_bytes())!=sha:
            raise RuntimeError('Release integrity mismatch: '+name)
    subprocess.run(['nginx','-t'],check=True)
    original=CONFIG.read_text();candidate=patch(original)
    before={p:route(p) for p in ROUTES}
    for p,result in before.items():
        if result['status']!=(401 if p in ['/site-analytics/','/creative-admin'] else 200):
            raise RuntimeError('Unhealthy existing route '+p)
    # Retain old hashed assets for visitors who opened the previous homepage.
    for file in (Path(OLD)/'assets').glob('*'):
        target=RELEASE/'site/assets'/file.name
        if file.is_file() and not target.exists():shutil.copy2(file,target)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup=Path('/root/xemory-backups')/('vault-'+stamp);backup.mkdir(parents=True,mode=0o700)
    shutil.copy2(CONFIG,backup/'nginx-site')
    rollback=backup/'rollback.sh'
    rollback.write_text('#!/bin/bash\nset -euo pipefail\ncp -p '+str(backup/'nginx-site')+' '+str(CONFIG)+'\nnginx -t\nsystemctl reload nginx\n')
    rollback.chmod(0o700)
    try:
        if CONFIG.read_text()!=original:raise RuntimeError('Concurrent routing change')
        CONFIG.write_text(candidate)
        subprocess.run(['nginx','-t'],check=True);subprocess.run(['systemctl','reload','nginx'],check=True)
        for name,sha in manifest.items():
            if not name.startswith('site/'):continue
            url='/' if name=='site/index.html' else '/kinetic/'+name[5:]
            expected={'status':200,'sha256':sha}
            for attempt in range(5):
                actual=route(url)
                if actual==expected:break
                time.sleep(1)
            if actual!=expected:raise RuntimeError('Live asset mismatch: '+url)
        after={p:route(p) for p in ROUTES}
        if after!=before:raise RuntimeError('Existing route changed')
        receipt={'status':'published_and_verified','url':DOMAIN,'release':str(RELEASE),'backup':str(backup),'rollback':str(rollback),'preserved_routes':after,'public_files_verified':sum(p.startswith('site/') for p in manifest)}
        (backup/'verification.json').write_text(json.dumps(receipt,indent=2))
        (RELEASE/'verification.json').write_text(json.dumps(receipt,indent=2))
        print(json.dumps(receipt,indent=2))
    except Exception:
        shutil.copy2(backup/'nginx-site',CONFIG)
        subprocess.run(['nginx','-t'],check=True);subprocess.run(['systemctl','reload','nginx'],check=True)
        print('Rolled back homepage routing; previous release remains intact.')
        raise
if __name__=='__main__':main()
