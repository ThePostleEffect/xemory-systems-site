# Prototype Instructions

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Confirmed design decisions — October 20, 2026

- Use displayed concept 3, `outputs/homepage-directions/03-kinetic-gallery.png`, as visual reference.
- The sculpture must become an actual moving 3D asset with fog flowing through its structure. This explicit user request authorizes procedural 3D geometry and shaders in place of the static reference sculpture.
- Keep artistic editorial hierarchy, ivory/silver/amber, invention and creative services, and smaller unnamed adhesive AI-button feature.
- Noir mood is only an accent. Refine motion, clarity, sharpness and composition until remaining improvements are marginal.
- Respect reduced motion and supply a visible pause. The button remains a prototype concept.
- Latest user refinement: the sculpture should fold inward on itself perpetually. Build a clearly readable continuous folding cycle, retaining the metallic finish and moving fog. The interpretation of folds flowing through a center and emerging underneath is an implementation proposal; the user has not yet reviewed that revised form.
- User subsequently opened the revised page in their browser, said it looks fantastic, and authorized shipping it. Replace the homepage completely while preserving all other existing pages and transferring existing site navigation. The approved inward-folding form should be retained.
- Deployed and verified October 20 at https://www.xemorysystems.com/. Exact `/` and `/kinetic/` are served from `/var/www/xemory-kinetic-20261020/site`; all other routes remain on the existing Next application at port 3005. Existing pages, private authentication and services were preserved. Deployment receipt: `outputs/xemory-homepage-launch.json`; current curated source bundle: `outputs/Xemory-Kinetic-Homepage-v3.zip`. Do not deploy the unrelated staged business release when updating this homepage.

## October 23, 2026 — new preview
User requests richer homepage sculpture and restored click-to-enter vault. The geometric object IS the door, continuously moving through itself; spiral, uncouple, unfold direction delegated to assistant. Mysterious almost-alive fog must travel through object. Review preview before publication. Preserve latest Woodcarving navigation.

October 23 refinement: User loves uncoupling/opening motion. Preserve it. Entrance should have dark-mode soft-neon color, no orange, reduced gray bleaching and better ripple definition. Homepage amber remains liked. Add smoke-like irregular fog through gaps and around sculpture, with subtle pointer reaction. Current interpretation: dark graphite/cyan edges and layered domain-warped fog with decaying local pointer disturbance.

October 24 background refinement: User likes pointer-reactive base fog but finds white background empty. Initially suggested geometric events over a couple minutes, then explicitly said taller fog behind sculpture alone would satisfy them and delegated aesthetic choice. Implemented taller layered smoke backdrop, quiet left copy area, slow two-minute density variation, same pause/offscreen clock. No added geometric slideshow. Local preview only.
