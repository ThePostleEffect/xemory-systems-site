import {useEffect,useRef,useState} from 'react';
import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import './vault.css';

const fogVertex=`varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`;
const fogFragment=`
uniform float time; uniform float seed; varying vec2 vUv;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=mat2(.8,-.6,.6,.8)*p*2.03+4.7;a*=.5;}return v;}
void main(){vec2 uv=vUv-.5;float t=time*.12;vec2 p=uv*4.+seed;
vec2 warp=vec2(fbm(p+vec2(t,-t*.6)),fbm(p+vec2(-t*.4,t)+5.));
float cloud=fbm(p+warp*2.7+vec2(t*.4,-t));
float stream=exp(-pow((uv.y-.16*sin(uv.x*7.+t+seed)) * 5.,2.));
float edge=smoothstep(.5,.24,abs(uv.x))*smoothstep(.5,.22,abs(uv.y));
float density=smoothstep(.3,.78,cloud)*stream*edge;
vec3 col=mix(vec3(.36,.48,.51),vec3(.48,.78,.86),smoothstep(.35,.8,cloud));
gl_FragColor=vec4(col,density*.30);}`;

export default function Vault({onEnter}){
 const timer=useRef(null);
 const host=useRef(null),opening=useRef(false),pausedRef=useRef(false),finish=useRef(onEnter);
 const [state,setState]=useState('waiting');
 const [paused,setPaused]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches);
 useEffect(()=>{pausedRef.current=paused;},[paused]);
 useEffect(()=>{finish.current=onEnter;},[onEnter]);
 useEffect(()=>()=>clearTimeout(timer.current),[]);
 useEffect(()=>{
  const el=host.current;let renderer;
  try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'default'});}catch{setState('fallback');return;}
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setClearColor(0x0b1013,0);
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.82;
  el.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(37,1,.1,80);
  camera.position.set(0,.1,12);
  const pmrem=new THREE.PMREMGenerator(renderer),room=new RoomEnvironment();
  const env=pmrem.fromScene(room,.05);scene.environment=env.texture;room.dispose();pmrem.dispose();
  scene.add(new THREE.HemisphereLight(0x8bafc5,0x080c16,.65));
  const amber=new THREE.PointLight(0x66cdda,13,15);amber.position.set(0,0,3);scene.add(amber);
  const rim=new THREE.DirectionalLight(0xa2c8ff,2);rim.position.set(-4,4,4);scene.add(rim);
  const assembly=new THREE.Group();scene.add(assembly);
  // Every square frame circulates around a closed meridian: inward at the
  // front, through the throat, and back around the outer shell.
  const frames=[],materials=[],geometries=[];
  const edgeGeo=new THREE.EdgesGeometry(new THREE.BoxGeometry(2.07,.067,.13));geometries.push(edgeGeo);
  const edgeMat=new THREE.LineBasicMaterial({color:0x72ccdc,transparent:true,opacity:.30});materials.push(edgeMat);
  const barGeo=new THREE.BoxGeometry(1,.067,.13);geometries.push(barGeo);
  const silver=new THREE.MeshStandardMaterial({color:0x24343f,metalness:.94,roughness:.28,envMapIntensity:.38});
  const gold=new THREE.MeshStandardMaterial({color:0x518b9b,metalness:.84,roughness:.25,emissive:0x3caabd,emissiveIntensity:.42,envMapIntensity:.4});
  materials.push(silver,gold);
  for(let i=0;i<36;i++){
   const group=new THREE.Group();assembly.add(group);
   for(let side=0;side<4;side++){
    const bar=new THREE.Mesh(barGeo,i%9===0?gold:silver);
    bar.rotation.z=side*Math.PI/2;bar.position.set(Math.sin(side*Math.PI/2),Math.cos(side*Math.PI/2),0);bar.scale.x=2.07;group.add(bar);
    const edge=new THREE.LineSegments(edgeGeo,edgeMat);edge.position.copy(bar.position);edge.rotation.copy(bar.rotation);group.add(edge);
   }
   frames.push(group);
  }
  const fog=[];
  for(let i=0;i<7;i++){
   const mat=new THREE.ShaderMaterial({vertexShader:fogVertex,fragmentShader:fogFragment,uniforms:{time:{value:0},seed:{value:i*3.7}},transparent:true,depthWrite:false,side:THREE.DoubleSide});
   const geo=new THREE.PlaneGeometry(9,5);materials.push(mat);geometries.push(geo);
   const mesh=new THREE.Mesh(geo,mat);mesh.position.z=-2+i*.7;mesh.rotation.z=(i-3)*.19;scene.add(mesh);fog.push(mesh);
  }
  let raf=0,time=0,previous=performance.now(),openTime=0,openStart=0,done=false;
  const resize=()=>{const w=el.clientWidth,h=el.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.position.z=w<h?30:12;camera.updateProjectionMatrix();};
  const ro=new ResizeObserver(resize);ro.observe(el);resize();
  function tick(now){
   const dt=Math.min((now-previous)/1000,.05);previous=now;
   if(!document.hidden){
    if(!pausedRef.current)time+=dt;
    if(opening.current){if(!openStart)openStart=now;openTime=(now-openStart)/1000;}
    const progress=THREE.MathUtils.smoothstep(openTime,0,2.8);
    frames.forEach((f,i)=>{
     const q=i/frames.length*Math.PI*2-time*.27;
     const radius=1.58+.92*Math.cos(q);
     f.scale.setScalar(radius);
     f.position.z=.92*Math.sin(q);
     f.rotation.z=Math.PI/4+.24*Math.sin(q)+time*.035;
     const angle=i/frames.length*Math.PI*2;
     f.position.x=Math.cos(angle)*progress*8;
     f.position.y=Math.sin(angle)*progress*7;
     f.rotation.y=progress*(i%2?1:-1)*1.3;
     f.rotation.z+=progress*(i%2?1:-1)*.8;
    });
    assembly.rotation.x=.13*Math.sin(time*.12);assembly.rotation.y=.17*Math.cos(time*.15);
    fog.forEach((f,i)=>{f.material.uniforms.time.value=time;f.position.y=.28*Math.sin(time*.19+i);f.rotation.z=(i-3)*.19+.09*Math.sin(time*.13+i);});
    camera.position.z-=(camera.position.z-(camera.aspect<1?30:12)+progress*2)*.03;
    renderer.render(scene,camera);
    if(openTime>3&&!done){done=true;finish.current();return;}
   }
   raf=requestAnimationFrame(tick);
  }raf=requestAnimationFrame(tick);
  return()=>{cancelAnimationFrame(raf);ro.disconnect();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());env.dispose();renderer.dispose();renderer.domElement.remove();};
 },[]);
 function enter(){if(opening.current)return;if(paused||state==='fallback'){finish.current();return;}opening.current=true;setState('opening');timer.current=setTimeout(()=>finish.current(),3100);}
 return <section className={`vault vault-${state}`} aria-label="Xemory entrance">
  <div className="vault-halo"/><div ref={host} className="vault-canvas"/>
  <header className="vault-brand">XEMORY <span>SYSTEMS</span></header>
  <div className="vault-caption"><span>BEYOND THE FAMILIAR</span><h1>A little <em>curiosity.</em><br/>A world of possibility.</h1></div>
  <button className="vault-object-hit" aria-label="Open the geometric vault" onClick={enter} disabled={state==='opening'}/>
  <div className="vault-invite"><button onClick={enter} disabled={state==='opening'}>{state==='opening'?'UNFOLDING…':'ENTER XEMORY'} <span>↗</span></button><p>Some things begin with a closer look.</p></div>
  <div className="vault-controls"><button onClick={()=>setPaused(p=>!p)} aria-pressed={paused}>{paused?'Play motion':'Pause motion'}</button><button onClick={()=>finish.current()}>Skip entrance ↗</button></div>
 </section>;
}





