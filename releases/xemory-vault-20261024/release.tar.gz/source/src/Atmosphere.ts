import * as THREE from 'three';

// A distant, depth-tested atmospheric layer. Independent slow currents blend
// over two minutes; no image/video loop and no extra canvas or renderer.
export function createAtmosphere() {
  const material = new THREE.ShaderMaterial({
    transparent: false, depthWrite: false, depthTest: false,
    blending: THREE.CustomBlending, blendSrc: THREE.SrcAlphaFactor, blendDst: THREE.OneMinusSrcAlphaFactor, blendEquation: THREE.AddEquation,
    uniforms: { uTime: { value: 0 }, uAspect: { value: 1 } },
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.999999,1.0);}`,
    fragmentShader: `
      uniform float uTime; uniform float uAspect; varying vec2 vUv;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
        return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float n=0.,a=.5;for(int i=0;i<5;i++){
        n+=a*noise(p);p=mat2(.8,-.6,.6,.8)*p*2.03+8.1;a*=.5;}return n;}
      void main(){
        vec2 uv=vUv;
        float t=uTime*.024;
        vec2 p=vec2(uv.x*max(uAspect,.65),uv.y)*4.2;
        // A rising stream and a slower cross-current create irregular billows.
        vec2 q=vec2(fbm(p+vec2(t,-t*.7)),fbm(p+vec2(-t*.6,-t*.9)+6.7));
        vec2 r=vec2(fbm(p+q*2.6+vec2(-t*.3,-t)),fbm(p+q*2.1+vec2(t*.4,-t*.65)+9.2));
        float cloud=fbm(p+r*3.1+vec2(0.,-t*.7));
        float wisps=fbm(p*1.8+r*2.2+vec2(t*.25,-t*.5));
        float breath=.5+.5*sin(uTime*6.2831853/120.);
        float centre=.65+.035*sin(uTime*.019);
        float body=exp(-pow((uv.x-centre)*2.25,2.0));
        float rise=smoothstep(.15,.4,uv.y)*(1.-smoothstep(.90,1.,uv.y));
        // Keep the left copy area quiet, but let tendrils extend behind the title.
        float clearCopy=mix(.20,1.,smoothstep(.25,.65,uv.x));
        float edge=smoothstep(0.,.15,uv.x)*(1.-smoothstep(.94,1.,uv.x));
        float density=smoothstep(.25,.72,cloud)*(0.66+wisps*.6);
        float amber=exp(-pow((uv.x-.69)*4.,2.0)-pow((uv.y-.50)*3.,2.0));
        vec3 smoke=mix(vec3(.27,.35,.38),vec3(.64,.40,.23),amber*.35);
        smoke=mix(smoke,vec3(.63,.70,.70),smoothstep(.48,.75,cloud)*.35);
        float alpha=density*body*rise*edge*clearCopy*(.64+breath*.12);
        gl_FragColor=vec4(smoke,alpha);
      }`,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2,2),material);
  mesh.frustumCulled=false;
  mesh.renderOrder=-100;
  return { mesh, update(time:number,aspect:number){material.uniforms.uTime.value=time;material.uniforms.uAspect.value=aspect;} };
}

