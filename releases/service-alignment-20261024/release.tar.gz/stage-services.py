#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,shutil,subprocess,urllib.request,time
BASE=Path('/var/www/xemory-logo-20261013')
NEW=Path('/var/www/xemory-services-20261024')
PACKAGE=Path(__file__).resolve().parent
def run(*args,**kw):return subprocess.run(args,check=True,**kw)
manifest=json.loads((PACKAGE/'manifest.json').read_text())
for item in manifest:
    p=PACKAGE/'patch'/item['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
    if item.get('before'):
        assert hashlib.sha256((BASE/item['path']).read_text().encode()).hexdigest()==item['before'], 'Live source changed: '+item['path']
assert not NEW.exists(),'Staging directory already exists; inspect it first'
assert shutil.disk_usage('/').free>400*1024**2,'Not enough free space to stage'
NEW.mkdir()
run('rsync','-a','--exclude=node_modules','--exclude=.next','--exclude=.git','--exclude=.local-data',str(BASE)+'/',str(NEW)+'/')
(NEW/'node_modules').symlink_to(BASE/'node_modules',target_is_directory=True)
for item in manifest:
    target=NEW/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(PACKAGE/'patch'/item['path'],target)
(NEW/'next.config.ts').write_text('import type { NextConfig } from "next";\nconst nextConfig: NextConfig = {devIndicators:false,experimental:{cpus:1}};\nexport default nextConfig;\n')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=384')
run('npm','run','build','--','--webpack',cwd=NEW,env=env)
# Keep older client chunks available for visitors with an already-open page.
run('rsync','-a','--ignore-existing',str(BASE/'.next/static')+'/',str(NEW/'.next/static')+'/')
procs=json.loads(subprocess.check_output(['pm2','jlist']))
old=next(p['pm2_env'] for p in procs if p['name']==BASE.name)
keys=['CREATIVE_DATA_DIR','CREATIVE_ADMIN_PROXY_TOKEN','CREATIVE_PUBLIC_ORIGIN','CREATIVE_REQUESTS_ENABLED','CREATIVE_STORAGE_LIMIT_MB','CONTACT_FROM_EMAIL','CONTACT_TO_EMAIL','RESEND_API_KEY']
values={k:old.get(k,old.get('env',{}).get(k)) for k in keys}
values={k:v for k,v in values.items() if v is not None};values['NODE_ENV']='production'
assert values.get('CREATIVE_DATA_DIR') and values.get('CREATIVE_ADMIN_PROXY_TOKEN'),'Missing existing private-request configuration'
config=Path('/root/xemory-services-20261024.ecosystem.json')
config.write_text(json.dumps({'apps':[{'name':NEW.name,'cwd':str(NEW),'script':str(NEW/'node_modules/next/dist/bin/next'),'args':['start','-H','127.0.0.1','-p','3008'],'env':values}]}));config.chmod(0o600)
run('pm2','start',str(config))
for attempt in range(20):
    try:
        body=urllib.request.urlopen('http://127.0.0.1:3008/lab',timeout=10).read().decode()
        assert 'BtMCN' in body and '36-Prompt Bundle' in body
        body=urllib.request.urlopen('http://127.0.0.1:3008/creative-request',timeout=10).read().decode()
        assert 'STARTING BUDGET' in body and 'service-starters' in body
        break
    except Exception:
        if attempt==19:raise
        time.sleep(1)
print('SERVICE_STAGING_PASSED: port 3008; live site unchanged',flush=True)
