#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,urllib.request,urllib.error
CONFIG=Path('/etc/nginx/sites-available/xemorysystems')
NEW=Path('/var/www/xemory-services-20261024')
def run(*args):subprocess.run(args,check=True)
def get(route):
    try:r=urllib.request.urlopen('https://www.xemorysystems.com'+route,timeout=30)
    except urllib.error.HTTPError as e:r=e
    return r.status,r.read()
assert (NEW/'.next/BUILD_ID').is_file()
unchanged=['/','/woodcarving/','/icon.svg','/robots.txt','/sitemap.xml']
before={p:get(p) for p in unchanged}
assert all(s==200 for s,b in before.values())
original=CONFIG.read_text()
count=original.count('proxy_pass http://127.0.0.1:3005;')
assert count>=2 and 'xemory-vault-20261024' in original,'Unexpected live routing'
candidate=original.replace('proxy_pass http://127.0.0.1:3005;','proxy_pass http://127.0.0.1:3008;')
backup=Path('/root/xemory-backups')/datetime.datetime.now(datetime.timezone.utc).strftime('services-%Y%m%dT%H%M%SZ');backup.mkdir(mode=0o700)
shutil.copy2(CONFIG,backup/'nginx-site')
(backup/'rollback.sh').write_text('#!/bin/bash\nset -euo pipefail\npm2 start xemory-logo-20261013\ncp -p '+str(backup/'nginx-site')+' '+str(CONFIG)+'\nnginx -t\nsystemctl reload nginx\npm2 stop xemory-services-20261024\npm2 save\n')
(backup/'rollback.sh').chmod(0o700)
try:
    assert CONFIG.read_text()==original,'Concurrent routing change'
    CONFIG.write_text(candidate);run('nginx','-t');run('systemctl','reload','nginx')
    for p,v in before.items():assert get(p)==v,'Preserved route changed: '+p
    for p in ['/about','/contact','/privacy','/terms','/lab','/creative-request','/downloads/xemory-creative-request.pdf','/creations/prompts.png']:
        assert get(p)[0]==200,p
    for p in ['/creative-admin','/site-analytics/']:assert get(p)[0]==401,'Admin protection changed'
    assert b'36-Prompt Bundle' in get('/lab')[1]
    assert b'CHOOSE A STARTING BUDGET' in get('/creative-request')[1]
    for p in ['downloads/xemory-creative-request.pdf','creations/prompts.png']:
        assert get('/'+p)[1]==(NEW/'public'/p).read_bytes(),p
    run('pm2','stop','xemory-logo-20261013');run('pm2','save')
    receipt={'status':'published_and_verified','release':str(NEW),'rollback':str(backup/'rollback.sh'),'preserved_routes':unchanged,'admin_status':401,'service_upstreams_changed':count}
    (NEW/'verification.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
except Exception:
    shutil.copy2(backup/'nginx-site',CONFIG);run('nginx','-t');run('systemctl','reload','nginx')
    print('Rolled back to the original service app.');raise
