Xemory homepage-only release

site/ is the public static web root; source/ and deploy/ must remain outside
every HTTP root.
SHA256SUMS covers every payload file except itself. Run sha256sum -c SHA256SUMS
after extraction from the release directory.

Expected extraction destination: /var/www/xemory-kinetic-20261020
Suggested routing: exact / -> site/index.html; /kinetic/ -> site/.
deploy/activate.py is the separately prepared, reviewable activation helper.
SHA256SUMS uses one "64-hex-sha256  relative/path" line per payload file.
To select public hashes, parse the two-space separator and keep paths starting
with "site/". Hash regular files relative to the release root; reject traversal.
Keep every other route on the existing Next application. Preserve current
authentication, private storage, analytics logging, TLS and security headers.

This archive does not change the server and does not establish that a release
has been deployed. The server administrator must inspect the active config,
save a private rollback copy, validate the candidate, and verify after cutover.
