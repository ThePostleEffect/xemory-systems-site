# Xemory Systems — Kinetic Gallery source

Static homepage source for the owner-approved October 20, 2026 release.
The release archive is preparation only; its existence is not evidence of deployment.

## Build

Use Node.js 20.19+ or 22.12+ and pnpm. From this source directory:

    pnpm install --frozen-lockfile
    pnpm build

The static result is dist/client. The production asset base is /kinetic/.
Source package scripts are intentionally reduced to static build/dev/preview;
the original working project's optional Sites worker scaffolding is not included.
Dependency versions and pnpm lock are retained.

## Routing and behavior

Serve the built index only for the exact homepage /. Map /kinetic/ to the
release's site/ directory. Existing Next application routes, form APIs,
private inboxes, analytics, downloads, icon, robots and sitemap stay in place.
The navigation retains Home, The Lab, Create with us, About and Contact;
the footer retains Terms and Privacy.

The project dialog prepares an email to pulselinkrocks@gmail.com; it does not
send a message or create a backend inquiry. The AI button is an unnamed
prototype concept and is not available to buy.

The inward-folding sculpture uses Three.js, an 18-second material-flow cycle,
fog, reflections, pause/reduced-motion support, and static WebP fallbacks.

## Source and assets

- src/App.jsx: page and navigation, native dialogs, email drafting.
- src/KineticScene.tsx: sculpture and scene lifecycle.
- src/styles.css: page layout, type, responsive styles.
- public/assets/*.webp: delivered artwork and fallback posters.
- licenses/: upstream runtime, font and build-tool licenses.

Original PNGs, QA captures, references, backups, node_modules, private files,
deployment configuration and the pre-eversion implementation are excluded.
