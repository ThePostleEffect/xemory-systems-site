import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ArrowRight, Pause, Play, X, Check, Copy, ArrowDown, List } from '@phosphor-icons/react';
import '@fontsource/cormorant-garamond/latin-400.css';
import '@fontsource/cormorant-garamond/latin-400-italic.css';
import '@fontsource/cormorant-garamond/latin-500.css';
import '@fontsource/manrope/latin-400.css';
import '@fontsource/manrope/latin-500.css';
import '@fontsource/manrope/latin-600.css';
const KineticScene = lazy(() => import('./KineticScene'));
const asset = (filename) => `${import.meta.env.BASE_URL}assets/${filename}`;

const services = [
  { title: 'Art & design', line: 'Ideas shaped with intention.', detail: 'Graphics, imagery, presentations and a visual world that feels unmistakably yours.', topic: 'Graphic design & imagery' },
  { title: 'Moving image & editing', line: 'Stories that move people.', detail: 'Video, motion and thoughtful editing. From the first frame to the finishing touches.', topic: 'Video & editing' },
  { title: 'Websites & automation', line: 'Technology that creates freedom.', detail: 'Distinctive websites, useful tools and workflows that give your time back.', topic: 'Websites & automation' },
];

const siteLinks = [
  { label: 'Home', href: '/' },
  { label: 'The Lab', href: '/lab' },
  { label: 'Create with us', href: '/creative-request' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
];

function SiteNavigation() {
  const [open, setOpen] = useState(false);
  const dialogRef = useRef(null);
  const toggleRef = useRef(null);
  useEffect(() => {
    if (!open) return;
    const menu = dialogRef.current;
    const previousOverflow = document.body.style.overflow;
    menu.showModal();
    menu.querySelector('a')?.focus();
    document.body.style.overflow = 'hidden';
    return () => {
      menu.close();
      document.body.style.overflow = previousOverflow;
      toggleRef.current?.focus({ preventScroll: true });
    };
  }, [open]);
  useEffect(() => {
    const desktop = window.matchMedia('(min-width: 761px)');
    const closeOnDesktop = e => { if (e.matches) setOpen(false); };
    desktop.addEventListener('change', closeOnDesktop);
    return () => desktop.removeEventListener('change', closeOnDesktop);
  }, []);
  return <>
    <nav className="desktop-navigation" aria-label="Main navigation">
      {siteLinks.slice(1).map(link => <a key={link.href} href={link.href}>{link.label}</a>)}
    </nav>
    <button ref={toggleRef} className="site-menu-toggle" aria-expanded={open} aria-controls="site-menu"
      aria-haspopup="dialog" onClick={() => setOpen(true)}>
      <span>Menu</span><List size={22} weight="light" />
    </button>
    <dialog id="site-menu" className="site-menu" ref={dialogRef} aria-labelledby="site-menu-title"
      onCancel={e => { e.preventDefault(); setOpen(false); }}
      onClick={e => { if (e.target === e.currentTarget) setOpen(false); }}>
      <div className="site-menu-panel">
        <div className="site-menu-heading">
          <span id="site-menu-title">XEMORY SYSTEMS</span>
          <button className="site-menu-close" aria-label="Close navigation" onClick={() => setOpen(false)}><X size={23} weight="light" /></button>
        </div>
        <nav className="mobile-navigation" aria-label="Main navigation">
          {siteLinks.map(link => <a key={link.href} href={link.href} aria-current={link.href === '/' ? 'page' : undefined}
            onClick={() => setOpen(false)}>{link.label}<ArrowUpRight size={21} weight="light" aria-hidden="true" /></a>)}
        </nav>
        <p className="site-menu-note">Independent ideas.<br />Thoughtfully made.</p>
      </div>
    </dialog>
  </>;
}

function Dialog({ type, topic, onClose }) {
  const ref = useRef(null);
  const returnFocus = useRef(document.activeElement);
  const emailAction = useRef(null);
  const [category, setCategory] = useState(topic || 'Something new');
  const [brief, setBrief] = useState('');
  const [name, setName] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [ready, setReady] = useState(false);
  useEffect(()=>{ if(ready) emailAction.current?.focus(); },[ready]);
  useEffect(()=>{setCopied(false);},[category,brief,name]);
  useEffect(() => {
    ref.current.showModal();
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; returnFocus.current?.focus?.(); };
  }, []);
  const emailBody = `Hi Daniel,\n\nI'd like to talk about ${category.toLowerCase()}.\n\n${brief.trim()}\n\nBest,\n${name.trim()}`;
  const emailHref = `mailto:pulselinkrocks@gmail.com?subject=${encodeURIComponent(`A new idea — ${category}`)}&body=${encodeURIComponent(emailBody)}`;
  async function copyBrief() {
    try { await navigator.clipboard.writeText(`To: pulselinkrocks@gmail.com\nSubject: A new idea — ${category}\n\n${emailBody}`); setCopied(true); }
    catch { setError('You can email your idea directly to pulselinkrocks@gmail.com.'); }
  }
  return <dialog aria-label={type==='lab'?'About the AI button concept':'Start a project'} className={`dialog ${type === 'lab' ? 'lab-dialog' : ''}`} ref={ref} onCancel={onClose} onClick={e => {if(e.target === e.currentTarget) onClose();}}>
    <button className="dialog-close" aria-label="Close dialog" onClick={onClose}><X size={23} weight="light" /></button>
    {type === 'lab' ? <>
      <img className="dialog-product" src={asset('lab-button-scene.webp')} alt="Concept rendering of a small round glossy black adhesive AI button" />
      <div className="dialog-inner">
        <p className="eyebrow">IN THE LAB · PROTOTYPE IN DEVELOPMENT</p>
        <h2>A little closer<br />to your everyday.</h2>
        <p>We’re exploring a small adhesive voice assistant for questions, answers and reminders, without having to reach for a screen.</p>
        <p>We’re building the first prototype around a nearby internet connection and preparing for initial testing. Its final name, performance and availability are still taking shape.</p>
        <p className="small-note">The images show a design concept. This product is not available to buy.</p>
        <a className="text-link" href="mailto:pulselinkrocks@gmail.com?subject=The%20Xemory%20AI%20button">Talk to us about the idea <ArrowUpRight size={20}/></a>
      </div>
    </> : <div className="dialog-inner">
      <p className="eyebrow">A CONVERSATION IS A GOOD BEGINNING</p>
      <h2>What are you<br /><em>imagining?</em></h2>
      <p>You don’t need a perfect brief. Tell us what you have in mind, and we’ll work out the possibilities together.</p>
      <form onSubmit={e=>{e.preventDefault();setReady(true);setError('');}}>
        <label>Your name<input value={name} onChange={e=>{setName(e.target.value);setReady(false);}} autoComplete="name" required placeholder="Your name" /></label>
        <label>What would you like to make?<select value={category} onChange={e=>{setCategory(e.target.value);setReady(false);}}>
          {['Something new', ...services.map(s=>s.topic), 'AI knowledge & business tools'].map(t=><option key={t}>{t}</option>)}
        </select></label>
        <label>A little about your idea<textarea rows={3} value={brief} required minLength={10} onChange={e=>{setBrief(e.target.value);setReady(false);}} placeholder="What would you love to create, change or make easier?" /></label>
        {!ready ? <button className="solid-button" type="submit">Prepare your message <ArrowRight size={20}/></button> :
          <div className="email-actions"><a ref={emailAction} className="solid-button" href={emailHref}>Open in your email app <ArrowUpRight size={20}/></a><button type="button" className="copy-button" onClick={copyBrief}>{copied?<Check size={19}/>:<Copy size={19}/>} {copied?'Copied':'Copy message'}</button></div>}
        <p className="small-note" aria-live="polite">{ready ? 'Your message is ready. Review and send it from your email app, or copy it. Nothing has been sent yet.' : 'We’ll discuss the scope, price and timing before any work begins. This opens an email draft; it doesn’t send anything automatically.'}</p>
        {error && <p role="alert" className="small-note">{error}</p>}
      </form>
    </div>}
  </dialog>;
}

export function App() {
  const [paused, setPaused] = useState(()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [dialog, setDialog] = useState(null);
  const [scene, setScene] = useState('loading');
  const openProject = (topic) => setDialog({ type:'project', topic });
  useEffect(() => {
    const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
    const change=e=>setPaused(e.matches);
    preference.addEventListener('change',change);
    return ()=>preference.removeEventListener('change',change);
  },[]);
  if (import.meta.env.DEV && new URLSearchParams(window.location.search).has('asset')) {
    return <section className="hero" aria-label="Sculpture preview"><Suspense fallback={null}><KineticScene paused={true}/></Suspense></section>;
  }
  return <>
    <a href="#main" className="skip-link">Skip to content</a>
    <main id="main">
      <section className="hero" aria-labelledby="hero-title" data-motion={paused?'paused':'playing'} data-renderer={scene}>
        <div className="scene-wrap" aria-hidden="true"><Suspense fallback={null}><KineticScene paused={paused} onReady={info=>setScene(info.mode)} /></Suspense></div>
        <header className="site-header">
          <a href="/" className="brand" aria-label="Xemory Systems home">
            <img src={asset('xemory-emblem.webp')} alt="" width="60" height="68"/>
            <span><strong>XEMORY</strong><small>SYSTEMS</small></span>
          </a>
          <div className="header-line" />
          <SiteNavigation />
        </header>
        <div className="hero-heading">
          <p className="eyebrow">XEMORY SYSTEMS — INVENTION &amp; CREATIVE TECHNOLOGY</p>
          <h1 id="hero-title">Where <em>imagination</em><br />takes form.</h1>
        </div>
        <div className="hero-intro">
          <span className="short-rule" />
          <p>Graphic design, editing,<br className="desktop-break"/> websites and automation.<br className="desktop-break"/> For ideas that deserve<br className="desktop-break"/> to become real.</p>
          <button className="solid-button" onClick={()=>openProject()}>Create with Xemory <ArrowUpRight size={20} weight="light"/></button>
        </div>
        <div className="hero-bottom">
          <a href="#capabilities" className="explore-cue"><ArrowDown size={18} weight="light"/><span>DISCOVER WHAT’S POSSIBLE</span></a>
          <button className="motion-control" disabled={scene==='fallback'} aria-pressed={paused} onClick={()=>setPaused(p=>!p)} aria-label={scene==='fallback'?'Still sculpture view':paused?'Play sculpture animation':'Pause sculpture animation'}>
            <span>{scene==='fallback'?'STILL VIEW':paused?'PLAY MOTION':'PAUSE MOTION'}</span>
            <span className="motion-icon">{paused?<Play size={17} weight="light"/>:<Pause size={17} weight="light"/>}</span>
          </button>
        </div>
      </section>
      <section className="capabilities" id="capabilities" aria-label="What we can make together">
        {services.map((s,i)=><button className="capability" key={s.title} onClick={()=>openProject(s.topic)}>
          <span className="service-index">0{i+1} /</span><span className="service-title">{s.title}</span>
          <span className="service-rule" /><span className="service-line">{s.line}</span>
          <span className="service-reveal">{s.detail} <ArrowUpRight size={20}/></span>
        </button>)}
      </section>
      <section className="lab" id="lab" aria-labelledby="lab-title">
        <img className="lab-art" src={asset('lab-button-scene.webp')} alt="Glossy black round AI-button concept on dark stone in amber light" loading="lazy" />
        <div className="lab-copy">
          <p className="eyebrow">IN THE LAB · PROTOTYPE IN DEVELOPMENT</p>
          <h2 id="lab-title">AI, within reach.</h2>
          <p>An adhesive voice assistant. A new idea taking shape.</p><span className="short-rule" />
          <button className="text-link" onClick={()=>setDialog({type:'lab'})}>Explore the concept <ArrowRight size={21} weight="light"/></button>
        </div>
      </section>
      <footer>
        <span className="footer-wordmark">XEMORY SYSTEMS</span><p>Independent ideas. Thoughtfully made.</p>
        <a href="https://payhip.com/xemoryproducts" target="_blank" rel="noreferrer">Explore the shop <ArrowUpRight size={16}/></a>
        <button onClick={()=>openProject()}>Let’s make something <ArrowUpRight size={16}/></button>
        <nav className="footer-legal" aria-label="Legal"><a href="/terms">Terms</a><a href="/privacy">Privacy</a></nav>
      </footer>
    </main>
    {dialog && <Dialog key={`${dialog.type}-${dialog.topic}`} {...dialog} onClose={()=>setDialog(null)}/>}
  </>;
}
