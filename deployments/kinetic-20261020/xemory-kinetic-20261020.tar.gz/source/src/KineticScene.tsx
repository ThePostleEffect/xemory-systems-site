import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Reflector } from 'three/addons/objects/Reflector.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

type KineticSceneProps = {
  paused: boolean;
  onReady?: (info: { mode: string }) => void;
};

const PI = Math.PI;
const FLOW_CYCLE_SECONDS = 18;
const FLOW_PERIOD = PI * 2;

// Closed material coordinates travel around the meridian. The non-circular
// radius belongs to the material, so this changes the actual surface shape.
function flowPoint(v: number, phi: number, phase: number, out: THREE.Vector3) {
  const azimuth = phi + 0.32 * Math.sin(v) + 0.07 * Math.sin(2 * v + phi);
  const rho = 0.97 * (1 + 0.16 * Math.cos(v) + 0.105 * Math.cos(2 * v) + 0.05 * Math.sin(3 * v + 2 * phi));
  const major = 1.98 + 0.12 * Math.cos(3 * azimuth + 0.5) + 0.06 * Math.sin(azimuth);
  const q = v + phase;
  const radial = major + rho * Math.cos(q);
  const localY = 1.28 * rho * Math.sin(q);
  const localZ = radial * Math.sin(azimuth) * 0.95;
  return out.set(radial * Math.cos(azimuth) * 1.11,
    2.55 + localY * 0.863 - localZ * 0.505,
    localY * 0.505 + localZ * 0.863);
}

// Periodic minimum-height samples keep the lower returning fold softly seated.
// Cubic interpolation preserves position and velocity through the 18s seam.
const FLOW_GROUND = [0.2710187,0.2904372,0.3107305,0.331959,0.3535426,0.3755537,0.396407,0.417742,0.4394003,0.4612204,0.4830395,0.5033705,0.5230521,0.5420659,0.5600028,0.5758907,0.5706965,0.5560691,0.5411489,0.526136,0.5106827,0.4958533,0.4818131,0.4686281,0.4559552,0.4443944,0.4340763,0.4248835,0.4164374,0.4094669,0.4038916,0.3988741,0.394809,0.3923599,0.3912321,0.3909927,0.3923694,0.3951725,0.3987194,0.4037935,0.4103227,0.4175988,0.426055,0.4344951,0.44379,0.4540055,0.4650111,0.4766715,0.4886213,0.4989799,0.5094096,0.5194318,0.5261247,0.5305668,0.5310805,0.5300719,0.5276483,0.5232951,0.5183755,0.5129422,0.5074289,0.5014909,0.4954962,0.4889889,0.4821265,0.4753335,0.4686358,0.4618835,0.4550731,0.4483936,0.4418391,0.4353975,0.4283668,0.4208515,0.4129528,0.4050559,0.3971255,0.3886518,0.3798751,0.3706186,0.3606319,0.3499887,0.338502,0.3261172,0.3129964,0.2989163,0.2842519,0.2690293,0.2531011,0.2367945,0.2205363,0.2044358,0.1886111,0.1731885,0.1583007,0.1439924,0.130214,0.1170416,0.1047973,0.0936209,0.0836511,0.0750238,0.0677427,0.0612647,0.0557729,0.0508062,0.0475069,0.0459769,0.0458117,0.0468583,0.0483984,0.0509051,0.0553381,0.0616265,0.0687138,0.0765116,0.0848664,0.0950226,0.1070892,0.1197617,0.1325449,0.1468127,0.1618837,0.1786415,0.195864,0.2127383,0.2310716,0.2507587];
function flowGround(phase: number) {
  const n = FLOW_GROUND.length;
  const sample = ((phase / FLOW_PERIOD) % 1 + 1) % 1 * n;
  const i = Math.floor(sample);
  const t = sample - i;
  const a = FLOW_GROUND[(i - 1 + n) % n], b = FLOW_GROUND[i % n];
  const c = FLOW_GROUND[(i + 1) % n], d = FLOW_GROUND[(i + 2) % n];
  return 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t
    + (-a + 3 * b - 3 * c + d) * t * t * t);
}

const flowGLSL = `
  uniform float uFlowPhase;
  attribute vec3 aFlow;
  attribute vec2 aFlowNormal;
  varying float vFlowInterior;
  vec3 flowPosition(float v, float phi, float phase) {
    float azimuth = phi + 0.32 * sin(v) + 0.07 * sin(2.0 * v + phi);
    float rho = 0.97 * (1.0 + 0.16 * cos(v) + 0.105 * cos(2.0 * v) + 0.05 * sin(3.0 * v + 2.0 * phi));
    float major = 1.98 + 0.12 * cos(3.0 * azimuth + 0.5) + 0.06 * sin(azimuth);
    float q = v + phase;
    float radial = major + rho * cos(q);
    float localY = 1.28 * rho * sin(q);
    float localZ = radial * sin(azimuth) * 0.95;
    return vec3(radial * cos(azimuth) * 1.11,
      2.55 + localY * 0.863 - localZ * 0.505,
      localY * 0.505 + localZ * 0.863);
  }
`;

function installFlow(material: THREE.MeshPhysicalMaterial, phase: { value: number }) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uFlowPhase = phase;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\n' + flowGLSL)
      .replace('#include <beginnormal_vertex>', `#include <beginnormal_vertex>
        vec3 flowCenter = flowPosition(aFlow.x, aFlow.y, uFlowPhase);
        vec3 flowAlong = normalize(flowPosition(aFlow.x + 0.001, aFlow.y, uFlowPhase)
          - flowPosition(aFlow.x - 0.001, aFlow.y, uFlowPhase));
        vec3 flowAcross = normalize(flowPosition(aFlow.x, aFlow.y + 0.001, uFlowPhase)
          - flowPosition(aFlow.x, aFlow.y - 0.001, uFlowPhase));
        vec3 flowSurface = normalize(cross(flowAlong, flowAcross));
        vec3 flowSide = normalize(cross(flowSurface, flowAlong));
        objectNormal = normalize(flowSurface * aFlowNormal.y + flowSide * aFlowNormal.x);
        vFlowInterior = smoothstep(0.15, 0.80, -cos(aFlow.x + uFlowPhase));`)
      .replace('#include <begin_vertex>', 'vec3 transformed = flowCenter + flowSurface * aFlow.z;');
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying float vFlowInterior;')
      .replace('#include <color_fragment>', `#include <color_fragment>
        diffuseColor.rgb *= mix(vec3(1.0), vec3(0.78, 0.52, 0.28), vFlowInterior * 0.38);`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        totalEmissiveRadiance += vec3(0.60, 0.115, 0.009) * pow(vFlowInterior, 3.0) * 0.18;`);
  };
  material.customProgramCacheKey = () => 'xemory-inward-meridian-v1';
}

function makeFlowBlade(index: number, count: number, segments: number) {
  const phi = index / count * FLOW_PERIOD;
  const halfWidth = FLOW_PERIOD / count * 0.46;
  const profiles = [[-1,0,-1,0],[-0.84,1,-0.35,1],[0.84,1,0.35,1],[1,0,1,0],[0.84,-1,0.35,-1],[-0.84,-1,-0.35,-1]];
  const positions: number[] = [], normals: number[] = [], uvs: number[] = [];
  const flow: number[] = [], flowNormals: number[] = [], indices: number[] = [];
  const center = new THREE.Vector3(), ahead = new THREE.Vector3(), behind = new THREE.Vector3();
  const along = new THREE.Vector3(), across = new THREE.Vector3(), surface = new THREE.Vector3();
  const side = new THREE.Vector3(), vertex = new THREE.Vector3(), normal = new THREE.Vector3();
  for (let j = 0; j <= segments; j++) {
    const v = j / segments * FLOW_PERIOD;
    const thickness = 0.014 + 0.003 * Math.sin(v + phi) ** 2;
    for (let k = 0; k < profiles.length; k++) {
      const profile = profiles[k], angle = phi + halfWidth * profile[0], depth = thickness * profile[1];
      flowPoint(v, angle, 0, center);
      flowPoint(v + 0.001, angle, 0, ahead); flowPoint(v - 0.001, angle, 0, behind);
      along.subVectors(ahead, behind).normalize();
      flowPoint(v, angle + 0.001, 0, ahead); flowPoint(v, angle - 0.001, 0, behind);
      across.subVectors(ahead, behind).normalize();
      surface.crossVectors(along, across).normalize();
      side.crossVectors(surface, along).normalize();
      vertex.copy(center).addScaledVector(surface, depth);
      normal.copy(surface).multiplyScalar(profile[3]).addScaledVector(side, profile[2]).normalize();
      positions.push(vertex.x, vertex.y, vertex.z); normals.push(normal.x, normal.y, normal.z);
      uvs.push(k / 5, j / segments); flow.push(v, angle, depth); flowNormals.push(profile[2], profile[3]);
      if (j < segments) {
        const a = j * 6 + k, b = j * 6 + ((k + 1) % 6);
        indices.push(a, b + 6, b, a, a + 6, b + 6);
      }
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setAttribute('aFlow', new THREE.Float32BufferAttribute(flow, 3));
  geometry.setAttribute('aFlowNormal', new THREE.Float32BufferAttribute(flowNormals, 2));
  geometry.setIndex(indices);
  geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 2.5, 0), 6);
  return geometry;
}
const fogVertexShader = `
  varying vec3 vWorld;
  varying vec2 vUv;
  void main() {
    vUv = uv;
    vec4 world = modelMatrix * vec4(position, 1.0);
    vWorld = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;

const fogFragmentShader = `
  uniform float uTime;
  uniform float uSeed;
  uniform float uOpacity;
  uniform float uHeight;
  uniform float uNear;
  varying vec3 vWorld;
  varying vec2 vUv;

  float hash(vec2 p) {
    p = fract(p * vec2(123.34, 345.45));
    p += dot(p, p + 34.345);
    return fract(p.x * p.y);
  }
  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
      mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
  }
  float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    mat2 turn = mat2(0.80, -0.60, 0.60, 0.80);
    for (int i = 0; i < 4; i++) {
      value += amplitude * noise(p);
      p = turn * p * 2.04 + vec2(13.1, 7.7);
      amplitude *= 0.5;
    }
    return value;
  }
  void main() {
    vec2 drift = vec2(uTime * 0.065, -uTime * 0.013);
    vec2 p = vec2(vWorld.x * 0.43, vWorld.y * 0.88) + vec2(uSeed, uSeed * 0.53);
    float warp = noise(p * 0.63 + drift * 0.72);
    float cloud = fbm(p + drift + vec2(warp * 1.8, warp * 0.65));
    float threads = noise(p * vec2(0.5, 2.1) + drift * 1.2);
    float plume = noise(vec2(vWorld.x * 0.30 + uSeed * 0.83, uTime * 0.028 + uSeed));
    float plumeHeight = uHeight * (0.53 + plume * 0.83);
    float height = pow(1.0 - smoothstep(0.10, plumeHeight, vWorld.y), 0.8);
    float edges = smoothstep(0.0, 0.16, vUv.x) * (1.0 - smoothstep(0.84, 1.0, vUv.x));
    float lowerEdge = smoothstep(0.0, 0.07, vUv.y);
    float density = smoothstep(0.28, 0.65, cloud) * (0.58 + threads * 0.42);
    float upperEdge = 1.0 - smoothstep(0.72, 1.0, vUv.y);
    float groundFade = smoothstep(0.055, 0.62, vWorld.y);
    float alpha = density * height * edges * lowerEdge * upperEdge * groundFade * uOpacity;
    float warm = exp(-pow((vWorld.x - 1.8) * 0.63, 2.0)) * exp(-vWorld.y * 0.6);
    vec3 mistColor = mix(vec3(0.62, 0.65, 0.64), vec3(1.04, 1.05, 1.0), uNear);
    vec3 color = mix(mistColor, vec3(1.0, 0.49, 0.13), warm * 0.38);
    color += cloud * 0.09;
    gl_FragColor = vec4(color, alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const reflectionShader = {
  uniforms: {
    color: { value: new THREE.Color(0x777770) },
    tDiffuse: { value: null },
    textureMatrix: { value: new THREE.Matrix4() },
    uTime: { value: 0 },
    uTexel: { value: new THREE.Vector2(1 / 1536, 1 / 1024) },
  },
  vertexShader: `
    uniform mat4 textureMatrix;
    varying vec4 vReflection;
    varying vec3 vWorld;
    void main() {
      vReflection = textureMatrix * vec4(position, 1.0);
      vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform vec2 uTexel;
    varying vec4 vReflection;
    varying vec3 vWorld;
    void main() {
      vec2 uv = vReflection.xy / vReflection.w;
      float ripple = sin(vWorld.z * 24.0 + vWorld.x * 0.7 + uTime * 0.24)
        * sin(vWorld.z * 8.1 - vWorld.x * 0.35) * 0.00047;
      uv.x += ripple;
      vec2 spread = uTexel * (2.0 + abs(vWorld.z) * 0.65);
      vec3 reflection = texture2D(tDiffuse, uv).rgb * 0.24;
      reflection += texture2D(tDiffuse, uv + vec2(spread.x, 0.0)).rgb * 0.12;
      reflection += texture2D(tDiffuse, uv - vec2(spread.x, 0.0)).rgb * 0.12;
      reflection += texture2D(tDiffuse, uv + vec2(0.0, spread.y)).rgb * 0.12;
      reflection += texture2D(tDiffuse, uv - vec2(0.0, spread.y)).rgb * 0.12;
      reflection += texture2D(tDiffuse, uv + spread).rgb * 0.07;
      reflection += texture2D(tDiffuse, uv - spread).rgb * 0.07;
      reflection += texture2D(tDiffuse, uv + vec2(spread.x, -spread.y)).rgb * 0.07;
      reflection += texture2D(tDiffuse, uv - vec2(spread.x, -spread.y)).rgb * 0.07;
      reflection = min(reflection, vec3(3.0));
      float striation = sin(vWorld.z * 75.0 + sin(vWorld.x * 0.7)) * 0.004;
      float grain = fract(sin(dot(floor(vWorld.xz * 160.0), vec2(12.9898, 78.233))) * 43758.5453);
      vec3 stone = vec3(0.021, 0.026, 0.027) + grain * 0.006;
      vec3 surface = mix(stone, reflection, 0.26) + striation;
      gl_FragColor = vec4(surface, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      float horizonHaze = 1.0 - smoothstep(-9.0, 1.0, vWorld.z);
      gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.9568627, 0.9372549, 0.9019608), horizonHaze);
    }
  `,
};

export default function KineticScene({ paused, onReady }: KineticSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const pausedRef = useRef(paused);
  const readyRef = useRef(onReady);
  const requestRenderRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    pausedRef.current = paused;
    requestRenderRef.current?.();
  }, [paused]);

  useEffect(() => {
    readyRef.current = onReady;
  }, [onReady]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
        failIfMajorPerformanceCaveat: false,
      });
    } catch {
      container.dataset.sceneStatus = 'unavailable';
      readyRef.current?.({ mode: 'fallback' });
      return;
    }

    const mobile = window.matchMedia('(max-width: 700px)').matches;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.3 : 1.5));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.87;
    renderer.shadowMap.enabled = false;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;';
    renderer.domElement.setAttribute('aria-hidden', 'true');
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#f4efe6');
    scene.fog = new THREE.FogExp2('#eee9de', 0.007);
    const camera = new THREE.PerspectiveCamera(29, 1, 0.1, 80);
    const cameraAim = new THREE.Vector3(0, 3.65, 0);
    const cameraHome = new THREE.Vector3(5.5, 6.0, 20);
    camera.position.copy(cameraHome);
    camera.lookAt(cameraAim);

    const environment = new THREE.Scene();
    environment.background = new THREE.Color('#11191d');
    const studioCards: THREE.Mesh[] = [];
    const addStudioCard = (w: number, h: number, xyz: number[], rgb: number[]) => {
      const card = new THREE.Mesh(
        new THREE.PlaneGeometry(w, h),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(rgb[0], rgb[1], rgb[2]), side: THREE.DoubleSide }),
      );
      card.position.set(xyz[0], xyz[1], xyz[2]);
      card.lookAt(0, 2, 0);
      environment.add(card);
      studioCards.push(card);
    };
    addStudioCard(8, 4, [-6, 8, 5], [4.4, 4.8, 5.3]);
    addStudioCard(1.4, 11, [7, 5, 3], [4.1, 4.6, 5.2]);
    addStudioCard(3, 9, [-7, 3, -4], [1.5, 1.8, 2.1]);
    addStudioCard(4, 7, [3, 4, -7], [5.2, 2.5, 0.8]);
    addStudioCard(7, 2, [0, 10, -2], [3.7, 3.6, 3.2]);
    const pmrem = new THREE.PMREMGenerator(renderer);
    let environmentTarget = pmrem.fromScene(environment, 0.035);
    scene.environment = environmentTarget.texture;
    studioCards.forEach((card) => {
      card.geometry.dispose();
      (card.material as THREE.Material).dispose();
    });
    pmrem.dispose();
    RectAreaLightUniformsLib.init();

    scene.add(new THREE.HemisphereLight('#e8eff3', '#352e27', 0.62));
    const keyLight = new THREE.DirectionalLight('#fff5df', 1.65);
    keyLight.position.set(-4.5, 10, 5);
    keyLight.castShadow = false;
    keyLight.shadow.mapSize.set(1536, 1536);
    keyLight.shadow.camera.left = -10;
    keyLight.shadow.camera.right = 10;
    keyLight.shadow.camera.top = 9;
    keyLight.shadow.camera.bottom = -8;
    keyLight.shadow.normalBias = 0.025;
    keyLight.shadow.bias = -0.00015;
    keyLight.shadow.radius = 4;
    scene.add(keyLight);

    const coolSoftbox = new THREE.RectAreaLight('#dce9f5', 2.8, 7, 5);
    coolSoftbox.position.set(1, 7, 8);
    coolSoftbox.lookAt(1, 2, 0);
    scene.add(coolSoftbox);
    const rearSoftbox = new THREE.RectAreaLight('#fff4dc', 3.8, 4, 7);
    rearSoftbox.position.set(-3, 5, -4);
    rearSoftbox.lookAt(1, 2, 0);
    scene.add(rearSoftbox);
    const coreLight = new THREE.PointLight('#ff7b12', 60, 5.5, 1.8);
    coreLight.position.set(1.85, 1.0, 0.6);
    scene.add(coreLight);
    const amberSoftbox = new THREE.RectAreaLight('#ff8b1c', 21, 1.4, 3.6);
    amberSoftbox.position.set(1.8, 2.0, 1.55);
    amberSoftbox.lookAt(2.0, 2.3, -1.0);
    scene.add(amberSoftbox);

    const metals = [
      new THREE.MeshPhysicalMaterial({
        color: '#919da3', metalness: 0.98, roughness: 0.21,
        clearcoat: 0.25, clearcoatRoughness: 0.24, envMapIntensity: 0.94,
        anisotropy: 0.25, anisotropyRotation: PI * 0.5,
      }),
      new THREE.MeshPhysicalMaterial({
        color: '#bac1c2', metalness: 0.98, roughness: 0.23,
        clearcoat: 0.24, clearcoatRoughness: 0.27, envMapIntensity: 0.90,
        anisotropy: 0.25, anisotropyRotation: PI * 0.5,
      }),
      new THREE.MeshPhysicalMaterial({
        color: '#77868e', metalness: 0.98, roughness: 0.25,
        clearcoat: 0.25, clearcoatRoughness: 0.25, envMapIntensity: 0.98,
        anisotropy: 0.3, anisotropyRotation: PI * 0.5,
      }),
    ];
    const innerMetal = new THREE.MeshPhysicalMaterial({
      color: '#b46c29', metalness: 0.91, roughness: 0.25,
      emissive: '#ef6208', emissiveIntensity: 0.34,
      clearcoat: 0.3, clearcoatRoughness: 0.24, envMapIntensity: 0.85,
    });
    const sculpture = new THREE.Group();
    sculpture.position.set(1.5, 0.09 - flowGround(0), 0);
    scene.add(sculpture);
    const flowPhase = { value: 0 };
    [...metals, innerMetal].forEach((material) => installFlow(material, flowPhase));
    const bladeCount = mobile ? 56 : 84;
    const groupedBlades = new Map<THREE.Material, THREE.BufferGeometry[]>();
    for (let i = 0; i < bladeCount; i++) {
      const material = i >= bladeCount * 0.55 && i < bladeCount * 0.60 ? innerMetal : metals[i % metals.length];
      const blades = groupedBlades.get(material) ?? [];
      blades.push(makeFlowBlade(i, bladeCount, mobile ? 80 : 128));
      groupedBlades.set(material, blades);
    }
    groupedBlades.forEach((blades, material) => {
      const merged = mergeGeometries(blades);
      blades.forEach((blade) => blade.dispose());
      if (!merged) return;
      merged.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 2.5, 0), 6);
      const mesh = new THREE.Mesh(merged, material);
      sculpture.add(mesh);
    });

    // An uninterrupted atmospheric backdrop keeps every pose clear of hard silhouettes.


    const reflectionWidth = mobile ? 768 : 1536;
    const reflectionHeight = mobile ? 512 : 1024;
    const ground = new Reflector(new THREE.PlaneGeometry(40, 60), {
      textureWidth: reflectionWidth,
      textureHeight: reflectionHeight,
      clipBias: 0.003,
      multisample: mobile ? 0 : 2,
      shader: reflectionShader,
    });
    ground.rotation.x = -PI * 0.5;
    ground.position.set(0, 0.055, 12);
    const groundShader = ground.material as THREE.ShaderMaterial;
    groundShader.uniforms.uTexel.value.set(1 / reflectionWidth, 1 / reflectionHeight);
    scene.add(ground);
    const groundShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(40, 60),
      new THREE.ShaderMaterial({
        vertexShader: `
          varying vec2 vGround;
          void main() {
            vec4 world = modelMatrix * vec4(position, 1.0);
            vGround = world.xz;
            gl_Position = projectionMatrix * viewMatrix * world;
          }`,
        fragmentShader: `
          varying vec2 vGround;
          void main() {
            vec2 a = (vGround - vec2(2.0, 0.7)) / vec2(2.1, 1.25);
            vec2 b = (vGround - vec2(-2.5, 0.5)) / vec2(3.3, 1.4);
            vec2 c = (vGround - vec2(6.8, 0.15)) / vec2(2.0, 1.0);
            float alpha = 0.30 * exp(-dot(a, a) * 1.5)
              + 0.07 * exp(-dot(b, b) * 1.6) + 0.14 * exp(-dot(c, c) * 1.5);
            gl_FragColor = vec4(vec3(0.025, 0.027, 0.028), alpha);
          }`,
        transparent: true,
        depthWrite: false,
      }),
    );
    groundShadow.rotation.x = -PI * 0.5;
    groundShadow.position.set(0, 0.061, 12);
    groundShadow.receiveShadow = true;
    scene.add(groundShadow);

    const fogMaterials: THREE.ShaderMaterial[] = [];
    const fogSlices = mobile ? 3 : 5;
    const fogMeshes: THREE.Mesh[] = [];
    for (let i = 0; i < fogSlices; i++) {
      const near = i / (fogSlices - 1);
      const fogMaterial = new THREE.ShaderMaterial({
        uniforms: {
          uTime: { value: 0 },
          uSeed: { value: i * 7.31 + 3.9 },
          uOpacity: { value: near < 0.4 ? 0.80 : 0.55 },
          uHeight: { value: THREE.MathUtils.lerp(5.1, 2.4, near) },
          uNear: { value: near },
        },
        vertexShader: fogVertexShader,
        fragmentShader: fogFragmentShader,
        transparent: true,
        depthWrite: false,
        depthTest: true,
        side: THREE.DoubleSide,
      });
      const backPlume = i < 2;
      const fog = new THREE.Mesh(new THREE.PlaneGeometry(backPlume ? 14 : 28, backPlume ? 6.4 : 5.0), fogMaterial);
      fog.position.set(i === 0 ? -3.6 : i === 1 ? 3.4 : 0, backPlume ? 2.65 : 2.27, -5.4 + near * 11.3);
      fog.renderOrder = 10 + i;
      fogMaterials.push(fogMaterial);
      fogMeshes.push(fog);
      scene.add(fog);
    }

    let frame = 0;
    let disposed = false;
    let contextLost = false;
    let inView = true;
    let firstRendered = false;
    const qaParameter = import.meta.env.DEV
      ? new URLSearchParams(window.location.search).get('sceneTime')
      : null;
    const qaTime = qaParameter !== null && Number.isFinite(Number(qaParameter))
      ? THREE.MathUtils.clamp(Number(qaParameter), 0, 600)
      : null;
    if (qaTime !== null) container.dataset.sceneQaClock = qaTime.toFixed(2);
    let time = qaTime ?? 0;
    let previousTime = performance.now();
    let lastRendered = 0;
    let needsRender = true;
    let reflectionDue = true;
    let renderCount = 0;
    let fpsEpoch = performance.now();
    let fpsFrames = 0;
    let renderCost = 0;
    let performanceSamples = 0;
    let adaptiveQuality = false;
    let schedulerThrottled = false;
    let lateFrames = 0;
    const pointer = new THREE.Vector2();
    const smoothPointer = new THREE.Vector2();
    const frameInterval = mobile ? 1000 / 30 : 1000 / 60;
    const updateReflection = ground.onBeforeRender.bind(ground);
    ground.onBeforeRender = (...args) => {
      if (reflectionDue || renderCount % (mobile || adaptiveQuality ? 3 : 2) === 0) {
        updateReflection(...args);
        reflectionDue = false;
      }
    };

    function setStatus() {
      if (contextLost) container!.dataset.sceneStatus = 'unavailable';
      else if (!inView || document.hidden) container!.dataset.sceneStatus = 'offscreen';
      else if (pausedRef.current) container!.dataset.sceneStatus = 'paused';
      else container!.dataset.sceneStatus = schedulerThrottled ? 'throttled' : 'ready';
    }

    function render(now: number) {
      frame = 0;
      if (disposed || contextLost) return;
      const active = qaTime === null && !pausedRef.current && inView && !document.hidden;
      const frameDelta = Math.max(0, (now - previousTime) / 1000);
      previousTime = now;
      if (active) {
        // Embedded browsers sometimes schedule a visible canvas at 1 Hz.
        // Keep its circulation progressing while still reporting that limit.
        if (frameDelta > 0.25) {
          lateFrames++;
        } else {
          lateFrames = 0;
          schedulerThrottled = false;
        }
        time += Math.min(frameDelta, 1.2);
        if (lateFrames > 1) schedulerThrottled = true;
      }
      if (needsRender || (active && now - lastRendered >= frameInterval - 1)) {
        needsRender = false;
        lastRendered = now;
        smoothPointer.lerp(pointer, 0.032);
        if (!pausedRef.current) {
          camera.position.x = cameraHome.x + smoothPointer.x * 0.43;
          camera.position.y = cameraHome.y - smoothPointer.y * 0.17;
          camera.lookAt(cameraAim);
        }
        const phase = (time % FLOW_CYCLE_SECONDS) / FLOW_CYCLE_SECONDS * FLOW_PERIOD;
        flowPhase.value = phase;
        sculpture.position.y = 0.09 - flowGround(phase) * sculpture.scale.y;
        coreLight.intensity = 60 + Math.sin(phase) * 3.0;
        amberSoftbox.intensity = 21 + Math.sin(phase * 2 + 0.2) * 1.1;
        fogMaterials.forEach((material) => { material.uniforms.uTime.value = time; });
        groundShader.uniforms.uTime.value = time;
        const renderStart = performance.now();
        renderer.render(scene, camera);
        renderCost += performance.now() - renderStart;
        renderCount++;
        fpsFrames++;
        const sampleNow = performance.now();
        if (sampleNow - fpsEpoch >= 1600) {
          const fps = fpsFrames * 1000 / (sampleNow - fpsEpoch);
          const averageFrameCost = renderCost / fpsFrames;
          container!.dataset.sceneFps = fps.toFixed(1);
          container!.dataset.sceneFrameMs = averageFrameCost.toFixed(1);
          if (fps < 5 && averageFrameCost < 12) schedulerThrottled = true;
          performanceSamples++;
          if (!adaptiveQuality && performanceSamples > 2 && fps >= 5 && fps < 22
            && !schedulerThrottled && !pausedRef.current && inView && !document.hidden) {
            adaptiveQuality = true;
            renderer.shadowMap.enabled = false;
            ground.getRenderTarget().setSize(768, 512);
            groundShader.uniforms.uTexel.value.set(1 / 768, 1 / 512);
            fogMeshes.forEach((fog, i) => { fog.visible = i === 0 || i === 2 || i === fogMeshes.length - 1; });
            container!.dataset.sceneQuality = 'balanced';
            reflectionDue = true;
          }
          fpsEpoch = sampleNow;
          fpsFrames = 0;
          renderCost = 0;
        }
        if (!firstRendered) {
          firstRendered = true;
          container!.dataset.sceneDetail = mobile ? '56-flowing-blades' : '84-flowing-blades';
          container!.dataset.sceneCycle = '18';
          readyRef.current?.({ mode: mobile ? 'webgl-mobile' : 'webgl' });
        }
        container!.dataset.sceneTime = time.toFixed(2);
        container!.dataset.sceneClock = qaTime !== null ? 'qa-fixed'
          : !active ? 'paused' : schedulerThrottled ? 'running-throttled' : 'running';
        setStatus();
      }
      if (active) frame = window.requestAnimationFrame(render);
    }

    function requestRender() {
      if (disposed || contextLost) return;
      needsRender = true;
      reflectionDue = true;
      previousTime = performance.now();
      if (!frame) {
        fpsEpoch = previousTime;
        fpsFrames = 0;
        renderCost = 0;
        frame = window.requestAnimationFrame(render);
      }
      setStatus();
    }
    requestRenderRef.current = requestRender;

    function resize() {
      const width = container!.clientWidth;
      const height = container!.clientHeight;
      if (!width || !height) return;
      const compact = width < 700;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, compact ? 1.3 : 1.5));
      renderer.setSize(width, height, false);
      const aspect = width / height;
      const viewHeight = compact ? 12.8 : 10.8;
      cameraAim.set(compact ? 1.7 : 0, compact ? 4.55 : 3.65, 0);
      cameraHome.set(cameraAim.x + 5.5, cameraAim.y + 0.65, 20);
      camera.aspect = aspect;
      camera.fov = 2 * Math.atan(viewHeight * 0.5 / cameraHome.distanceTo(cameraAim)) * 180 / PI;
      camera.position.copy(cameraHome);
      camera.lookAt(cameraAim);
      camera.updateProjectionMatrix();
      sculpture.scale.setScalar(compact ? Math.min(0.70, (width - 32) / height * viewHeight / 7.2) : 1.02);
      sculpture.position.x = compact ? 1.75 : 1.9;
      sculpture.position.y = 0.09 - flowGround(flowPhase.value) * sculpture.scale.y;
      requestRender();
    }
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    const intersectionObserver = new IntersectionObserver((entries) => {
      inView = entries[0]?.isIntersecting ?? true;
      if (!inView && frame) {
        cancelAnimationFrame(frame);
        frame = 0;
      }
      setStatus();
      if (inView) requestRender();
    }, { rootMargin: '100px', threshold: 0.01 });
    intersectionObserver.observe(container);
    const onVisibilityChange = () => {
      if (document.hidden && frame) {
        cancelAnimationFrame(frame);
        frame = 0;
      }
      setStatus();
      if (!document.hidden && inView) requestRender();
    };
    const onPointerMove = (event: PointerEvent) => {
      if (event.pointerType === 'touch' || pausedRef.current || !inView) return;
      const bounds = container!.getBoundingClientRect();
      pointer.set(
        THREE.MathUtils.clamp((event.clientX - bounds.left) / bounds.width - 0.5, -0.5, 0.5),
        THREE.MathUtils.clamp((event.clientY - bounds.top) / bounds.height - 0.5, -0.5, 0.5),
      );
    };
    const onPointerLeave = () => { pointer.set(0, 0); };
    const onContextLost = (event: Event) => {
      event.preventDefault();
      contextLost = true;
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      renderer.domElement.style.visibility = 'hidden';
      setStatus();
      readyRef.current?.({ mode: 'fallback' });
    };
    const onContextRestored = () => {
      try {
        // Render-target textures contain GPU-only pixels, so recreating buffers
        // alone cannot recover the studio environment after context loss.
        const restoredPmrem = new THREE.PMREMGenerator(renderer);
        const restoredEnvironment = restoredPmrem.fromScene(environment, 0.035);
        restoredPmrem.dispose();
        studioCards.forEach((card) => {
          card.geometry.dispose();
          (card.material as THREE.Material).dispose();
        });
        environmentTarget.dispose();
        environmentTarget = restoredEnvironment;
        scene.environment = environmentTarget.texture;
        contextLost = false;
        firstRendered = false;
        renderer.domElement.style.visibility = 'visible';
        requestRender();
      } catch {
        contextLost = true;
        renderer.domElement.style.visibility = 'hidden';
        setStatus();
        readyRef.current?.({ mode: 'fallback' });
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    document.documentElement.addEventListener('pointerleave', onPointerLeave);
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);
    resize();

    return () => {
      disposed = true;
      requestRenderRef.current = null;
      if (frame) cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pointermove', onPointerMove);
      document.documentElement.removeEventListener('pointerleave', onPointerLeave);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          geometries.add(object.geometry);
          const objectMaterials = Array.isArray(object.material) ? object.material : [object.material];
          objectMaterials.forEach((material) => materials.add(material));
        }
      });
      geometries.forEach((geometry) => geometry.dispose());
      materials.forEach((material) => material.dispose());
      ground.getRenderTarget().dispose();
      environmentTarget.dispose();
      keyLight.shadow.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="kinetic-scene"
      data-scene-status="loading"
      aria-hidden="true"
      style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}
    />
  );
}
