#!/usr/bin/env python3
"""Activate only the approved homepage; preserve the running Next application."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request

CONFIG = Path("/etc/nginx/sites-available/xemorysystems")
RELEASE = Path("/var/www/xemory-kinetic-20261020")
MARKER = "# Xemory kinetic homepage 2026-10-20"
DOMAIN = "https://www.xemorysystems.com"
PRESERVED = ["/lab", "/creative-request", "/about", "/contact", "/terms",
             "/privacy", "/site-analytics/", "/creative-admin", "/robots.txt",
             "/sitemap.xml", "/icon.svg"]


def homepage_locations(release):
    return f"""{MARKER}
    location = / {{
        root {release}/site;
        try_files /index.html =404;
        add_header Cache-Control "no-store, no-cache, max-age=0, must-revalidate" always;
        add_header X-Content-Type-Options "nosniff" always;
    }}
    location ^~ /kinetic/ {{
        alias {release}/site/;
        autoindex off;
        add_header Cache-Control "public, max-age=3600, must-revalidate" always;
        add_header X-Content-Type-Options "nosniff" always;
    }}
    # End Xemory kinetic homepage
"""


def patched_config(original, release=RELEASE):
    if MARKER in original or re.search(r"location\s+=\s+/\s*\{", original):
        raise ValueError("An exact homepage override already exists; inspect before proceeding.")
    if re.search(r"location[^{]*?/kinetic/", original):
        raise ValueError("The /kinetic/ prefix is already in use.")
    if "server_name xemorysystems.com www.xemorysystems.com;" not in original:
        raise ValueError("Unexpected production server identity.")
    if "listen 443 ssl;" not in original:
        raise ValueError("Expected HTTPS server was not found.")
    matches = list(re.finditer(r"(?m)^[ \t]*location / \{", original))
    if len(matches) != 1:
        raise ValueError("Expected one existing application location.")
    start = matches[0].start()
    # Add sibling locations. All original config bytes remain in their order.
    return original[:start] + homepage_locations(release) + original[start:]


def read_route(route):
    request = urllib.request.Request(DOMAIN + route, headers={
        "User-Agent": "XemoryDeploymentVerification/1.0", "Cache-Control": "no-cache"})
    try:
        response = urllib.request.urlopen(request, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    body = response.read()
    return {"status": response.status, "sha256": hashlib.sha256(body).hexdigest(),
            "type": response.headers.get("Content-Type", ""), "bytes": len(body)}


def install_config(text):
    temporary = CONFIG.with_name(CONFIG.name + ".kinetic-new")
    if temporary.exists():
        raise RuntimeError("Previous temporary config exists; inspect before retry.")
    temporary.write_text(text)
    shutil.copystat(CONFIG, temporary)
    os.replace(temporary, CONFIG)


def run():
    if os.geteuid() != 0:
        raise RuntimeError("Run through the existing authorized root console.")
    if RELEASE.resolve() != RELEASE:
        raise RuntimeError("Release must be a direct, dedicated directory.")
    site = RELEASE / "site"
    index = site / "index.html"
    html = index.read_text()
    if "Where imagination takes form" not in html or "/kinetic/assets/" not in html:
        raise RuntimeError("The approved production build is missing.")
    if not (site / "assets/sculpture-poster-desktop.webp").is_file():
        raise RuntimeError("The sculpture fallback is missing.")
    for relative in re.findall(r'(?:src|href)="(/kinetic/[^"]+)"', html):
        if not (site / relative.removeprefix("/kinetic/")).is_file():
            raise RuntimeError(f"Missing homepage dependency: {relative}")
    subprocess.run(["nginx", "-t"], check=True)
    original = CONFIG.read_text()
    candidate = patched_config(original)
    before = {route: read_route(route) for route in PRESERVED}
    if any(before[route]["status"] != 200 for route in PRESERVED
           if route not in {"/site-analytics/", "/creative-admin"}):
        raise RuntimeError("An existing public page is unhealthy before cutover.")
    if any(before[route]["status"] != 401 for route in ["/site-analytics/", "/creative-admin"]):
        raise RuntimeError("Existing private routes are not responding as expected.")
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = Path("/root/xemory-backups") / f"kinetic-{stamp}"
    backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    shutil.copy2(CONFIG, backup / "nginx-site")
    (backup / "routes-before.json").write_text(json.dumps(before, indent=2))
    (backup / "original-sha256").write_text(hashlib.sha256(original.encode()).hexdigest() + "\n")
    rollback = backup / "rollback.sh"
    rollback.write_text(
        "#!/bin/bash\nset -euo pipefail\n"
        f"cp -p '{backup}/nginx-site' '{CONFIG}'\n"
        "nginx -t\nsystemctl reload nginx\n"
        "printf 'Previous homepage routing restored. Existing application was never stopped.\\n'\n")
    rollback.chmod(0o700)
    changed = False
    try:
        if CONFIG.read_text() != original:
            raise RuntimeError("Production config changed during preparation; stopping.")
        install_config(candidate)
        changed = True
        subprocess.run(["nginx", "-t"], check=True)
        subprocess.run(["systemctl", "reload", "nginx"], check=True)
        expected = hashlib.sha256(index.read_bytes()).hexdigest()
        for _ in range(8):
            current = read_route("/")
            if current["status"] == 200 and current["sha256"] == expected:
                break
            time.sleep(0.5)
        else:
            raise RuntimeError("Public homepage does not match the approved artifact.")
        after = {route: read_route(route) for route in PRESERVED}
        differences = [route for route in PRESERVED if after[route] != before[route]]
        if differences:
            raise RuntimeError("An existing route changed: " + ", ".join(differences))
        result = {"status": "deployed", "release": str(RELEASE), "url": DOMAIN,
                  "backup": str(backup), "rollback": str(rollback),
                  "homepage_sha256": expected, "preserved_routes": after,
                  "existing_app": "Unmodified and still running on port 3005"}
        (backup / "verification.json").write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))
    except Exception:
        if changed:
            shutil.copy2(backup / "nginx-site", CONFIG)
            subprocess.run(["nginx", "-t"], check=True)
            subprocess.run(["systemctl", "reload", "nginx"], check=True)
            print("ROLLED BACK: previous routing restored; release files retained.")
        raise


if __name__ == "__main__":
    run()
