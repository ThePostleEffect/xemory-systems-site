const form=document.querySelector('#commission-form');
const prepared=document.querySelector('#prepared');
const draft=document.querySelector('#draft');
const status=document.querySelector('#draft-status');
document.querySelectorAll('.piece-gallery').forEach(gallery=>gallery.querySelectorAll('[data-photo]').forEach(button=>button.addEventListener('click',()=>{const main=gallery.querySelector('.gallery-main');main.src='assets/'+button.dataset.photo;main.alt=button.dataset.alt;gallery.querySelectorAll('[data-photo]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));})));
document.querySelectorAll('[data-category]').forEach(link=>link.addEventListener('click',()=>{form.elements.piece.value=link.dataset.category;prepared.hidden=true;}));
form.addEventListener('input',()=>{prepared.hidden=true;form.elements.name.setCustomValidity('');form.elements.idea.setCustomValidity('');});
form.addEventListener('submit',event=>{
 event.preventDefault();
 const data=new FormData(form);
 const value=key=>String(data.get(key)||'').trim();
 if(!value('name')||value('idea').length<10){form.elements.name.setCustomValidity(value('name')?'':'Please enter your name.');form.elements.idea.setCustomValidity(value('idea').length>=10?'':'Please add a little more about your idea.');form.reportValidity();return;}
 const pictured=value('piece').startsWith('Pictured');
 const subject=`Wood carving inquiry — ${value('piece')}`;
 const lines=['Hi Daniel,', '', pictured?`I’m interested in the ${value('piece').toLowerCase()}.`:`I’d like to discuss a custom carving: ${value('piece')}.`, '', value('idea'), ''];
 for(const [key,label] of [['details','Size, wood, or finish'],['budget','Budget (USD)'],['timing','Timing'],['location','Delivery location']])if(value(key))lines.push(`${label}: ${value(key)}`);
 lines.push('', 'Best,',value('name'));
 const body=lines.join('\n');
 draft.value=`To: pulselinkrocks@gmail.com\nSubject: ${subject}\n\n${body}`;
 document.querySelector('#email-link').href=`mailto:pulselinkrocks@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
 status.textContent='Review your message below. Nothing has been sent yet.';
 document.querySelector('#copy').textContent='Copy message';
 prepared.hidden=false;
 document.querySelector('#email-link').focus();
});
document.querySelector('#copy').addEventListener('click',async()=>{
 try{await navigator.clipboard.writeText(draft.value);document.querySelector('#copy').textContent='Copied';status.textContent='Copied. Paste this into your email and send it when you’re ready.';}
 catch{draft.focus();draft.select();status.textContent='Select and copy the message above, then paste it into your email.';}
});
