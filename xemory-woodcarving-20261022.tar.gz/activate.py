#!/usr/bin/env python3
"""Publish the approved carving page and homepage navigation, preserving the app."""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, urllib.request, urllib.error

CONFIG = Path('/etc/nginx/sites-available/xemorysystems')
RELEASE = Path('/var/www/xemory-woodcarving-20261022')
OLD_HOME = '/var/www/xemory-kinetic-20261020/site'
DOMAIN = 'https://www.xemorysystems.com'
ROUTES = ['/lab','/creative-request','/about','/contact','/terms','/privacy','/site-analytics/','/creative-admin','/robots.txt','/sitemap.xml','/icon.svg']

def patch(original):
    if '/woodcarving' in original:
        raise ValueError('Existing carving route: inspect before replacing')
    if original.count(OLD_HOME) != 2 or '# Xemory kinetic homepage 2026-10-20' not in original:
        raise ValueError('Homepage routing changed; inspect before deployment')
    anchor = '    location / {'
    if original.count(anchor) != 1:
        raise ValueError('Unexpected application routing')
    addition = '''    # Xemory woodcarving 2026-10-22
    location = /woodcarving { return 301 /woodcarving/; }
    location ^~ /woodcarving/ {
        alias /var/www/xemory-woodcarving-20261022/woodcarving/;
        index index.html;
        autoindex off;
        add_header Cache-Control "no-cache" always;
        add_header X-Content-Type-Options "nosniff" always;
    }
    # End Xemory woodcarving
'''
    return original.replace(OLD_HOME, (RELEASE / 'homepage').as_posix()).replace(anchor, addition+anchor)

def route(url):
    req=urllib.request.Request(DOMAIN+url,headers={'Cache-Control':'no-cache','User-Agent':'XemoryLaunchVerification/1.0'})
    try: response=urllib.request.urlopen(req,timeout=30)
    except urllib.error.HTTPError as e: response=e
    data=response.read()
    return {'status':response.status,'sha256':hashlib.sha256(data).hexdigest()}

def main():
    if os.geteuid()!=0: raise RuntimeError('Use the existing authorized root console')
    for name in ['woodcarving/index.html','homepage/index.html']:
        if not (RELEASE/name).is_file(): raise RuntimeError('Missing release file: '+name)
    html=(RELEASE/'woodcarving/index.html').read_text()
    if 'noindex' in html or '35%' not in html or 'Three progress updates' not in html:
        raise RuntimeError('Unexpected carving artifact')
    for match in re.findall(r'(?:src|href)="([^"#]+)"',html):
        if not match.startswith(('http','mailto:')) and not (RELEASE/'woodcarving'/match).is_file():
            raise RuntimeError('Missing page asset: '+match)
    subprocess.run(['nginx','-t'],check=True)
    original=CONFIG.read_text()
    candidate=patch(original)
    before={r:route(r) for r in ROUTES}
    for r,result in before.items():
        if result['status'] != (401 if r in ['/site-analytics/','/creative-admin'] else 200):
            raise RuntimeError('Unhealthy route before deployment: '+r)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup=Path('/root/xemory-backups')/('woodcarving-'+stamp)
    backup.mkdir(parents=True,mode=0o700)
    shutil.copy2(CONFIG,backup/'nginx-site')
    rollback=backup/'rollback.sh'
    rollback.write_text('#!/bin/bash\nset -euo pipefail\ncp -p '+str(backup/'nginx-site')+' '+str(CONFIG)+'\nnginx -t\nsystemctl reload nginx\n')
    rollback.chmod(0o700)
    try:
        if CONFIG.read_text()!=original: raise RuntimeError('Routing changed during preparation')
        CONFIG.write_text(candidate)
        subprocess.run(['nginx','-t'],check=True)
        subprocess.run(['systemctl','reload','nginx'],check=True)
        for url,file in [('/woodcarving/','woodcarving/index.html'),('/','homepage/index.html'),('/woodcarving/assets/cane-full.jpg','woodcarving/assets/cane-full.jpg'),('/woodcarving/sunset.css','woodcarving/sunset.css')]:
            expected=hashlib.sha256((RELEASE/file).read_bytes()).hexdigest()
            actual=route(url)
            if actual!={'status':200,'sha256':expected}: raise RuntimeError('Live verification mismatch: '+url)
        after={r:route(r) for r in ROUTES}
        if after!=before: raise RuntimeError('Existing page changed during deployment')
        receipt={'status':'page_published_checkout_pending','url':DOMAIN+'/woodcarving/','release':str(RELEASE),'backup':str(backup),'rollback':str(rollback),'preserved_routes':after}
        (backup/'verification.json').write_text(json.dumps(receipt,indent=2))
        print(json.dumps(receipt,indent=2))
    except Exception:
        shutil.copy2(backup/'nginx-site',CONFIG)
        subprocess.run(['nginx','-t'],check=True)
        subprocess.run(['systemctl','reload','nginx'],check=True)
        print('Rolled back website routing. Release files retained.')
        raise

if __name__=='__main__': main()
